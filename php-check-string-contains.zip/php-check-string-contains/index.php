<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check String if contains [string] in PHP</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.6.2.min.js" integrity="sha256-2krYZKh//PcchRtd+H+VyyQoZ/e3EcrkxhM8ycwASPA=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js" integrity="sha512-naukR7I+Nk6gp7p5TMA4ycgfxaZBJ7MO5iC3Fp6ySQyKFHOGfpkSZkYVWV5R7u7cfAicxanwYQ5D1e17EfJcMA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

    <style>
        html, body{
            height: 100%;
            width: 100%;
        }
        body{
            display: flex;
            height: 100%;
            width: 100%;
            flex-direction: column;
        }
        body>nav, body>footer{
            flex-shrink: 1;
        }
        body>main{
            flex-shrink: 1;
            flex-grow: 1;
            overflow: auto;
            margin: 1em 0;
        }
        .badge.rouded-circle {
            border-radius: 100%;
            font-size: 13px;
            padding: 0.5em;
            height: 25px;
            width: 25px;
            text-align: center;
        }
    </style>
</head>
<body style="background:#EEF1FF">
    <nav class="navbar navbar-expand-lg navbar-dark" style="background:#7FBCD2">
        <div class="container">
            <a class="navbar-brand" href="./">Check String if contains [string] in PHP</a>
            <div>
                <a href="https://sourcecodester.com" class="text-light fw-bolder h6 text-decoration-none" target="_blank">SourceCodester</a>
            </div>
        </div>
    </nav>

    <main class="container-fluid">
        <div class="col-lg-6 col-md-8 col-sm-12 col-xs-12 mx-auto">
            <h2 class="text-center">Checking if the String contains a specific string using PHP</h2>
            <hr>

            <div class="card mt-3 rounded-0">
                <div class="card-header">
                    <div class="card-title"><b>Check List</b></div>
                </div>
                <div class="card-body rounded-0">
                    <div class="container-fluid">
                        <?php 
                        $use = isset($_GET['use']) ? $_GET['use'] : 'strstr';
                        ?>
                        <h3 class="text-center"><b>Using "<?= $use ?>"</b></h3>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr class="bg gradient bg-primary text-light">
                                        <th class="p-1">Phrase</th>
                                        <th class="p-1">Find</th>
                                        <th class="p-1">Containing</th>
                                        <th class="p-1">Return Value</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
                                $data = file_get_contents("data.json");
                                $data = json_decode($data);
                                // print_r($data);exit;
                                foreach($data as $row):
                                    switch($use){
                                        case 'strstr':
                                            $check = strstr(strtolower($row->phrase), strtolower($row->find));
                                            $is_containing = ($check) ? true : false;
                                            break;
                                        case 'strpos':
                                            $check = strpos(strtolower($row->phrase), strtolower($row->find));
                                            $is_containing = ($check > -1) ? true : false;
                                            break;
                                        case 'str_contains':
                                            $check = str_contains(strtolower($row->phrase), strtolower($row->find));
                                            $is_containing = ($check) ? true : false;
                                            break;
                                        case 'preg_match':
                                            $check = preg_match("/{$row->find}/i", $row->phrase, $matches);
                                            $is_containing = ($check) ? true : false;
                                            break;
                                    }

                                ?>
                                <tr>
                                    <td class="p-1"><?= $row->phrase ?></td>
                                    <td class="p-1"><?= $row->find ?></td>
                                    <td class="p-1 text-center">
                                        <?php if($is_containing): ?>
                                            <span class="badge rouded-circle bg-success bg-gradient text-light"><i class="fa-solid fa-check"></i></span>
                                        <?php else: ?>
                                            <span class="badge rouded-circle bg-danger bg-gradient text-light"><i class="fa-solid fa-times"></i></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-1"><?= is_bool($check) ? (($check) ? 'true' : 'false') : $check ?></td>
                                </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="card-footer py-2">
                    <div class="row justify-content-center">
                        <div class="col-lg-3 col-md-6 col-sm-10 col-xs-12">
                            <a class="btn btn-block w-100 btn-primary rounded-pill" href="./?use=strstr">strstr</a>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-10 col-xs-12">
                            <a class="btn btn-block w-100 btn-warning border rounded-pill" href="./?use=strpos">strpos</a>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-10 col-xs-12">
                            <a class="btn btn-block w-100 btn-info border rounded-pill" href="./?use=str_contains">str_contains</a>
                        </div>
                        
                        <div class="col-lg-3 col-md-6 col-sm-10 col-xs-12">
                            <a class="btn btn-block w-100 btn-success border rounded-pill" href="./?use=preg_match">preg_match</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<footer class="container-fluid py-3" style="background:#7FBCD2; color:#fff">
    <div class="container-fluid my-2">
        <div class="text-center">
            <b>Check String if contains [string] in PHP &copy; 2022</b>
        </div>
    </div>
</footer>
</body>
</html>